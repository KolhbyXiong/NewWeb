package com.hgdiv.opendata.model;

/**
 * The type Albums.
 */
public class Albums extends Data<Album>{

}
