package com.hgdiv.opendata.model;

/**
 * The type Tracks.
 */
public class Tracks extends Data<Track> {
}