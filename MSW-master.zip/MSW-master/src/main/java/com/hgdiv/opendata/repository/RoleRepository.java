package com.hgdiv.opendata.repository;

import com.hgdiv.opendata.model.Role;
import org.springframework.data.jpa.repository.JpaRepository;

public interface RoleRepository extends JpaRepository<Role, Long>{
}
