package com.hgdiv.app;



class WebApplicationTests {
//
//	public static void main(String[] args) {
//		int duration = 2324;
//		int res = duration / 60;
//		int decimalPoints = duration % 60;
//		System.out.println("Formatted Duration: " + res + " min" + " and " + decimalPoints + " sec");
//	}

}
